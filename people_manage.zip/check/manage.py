import pymysql
import json

def getConnection():
    result = pymysql.connect(host = '192.168.1.232',
                             user = ' root ',
                             port = 3306,
                             password = '123456!',
                             db = 'PEOPLE',
                             charset = 'utf8mb4',
                             use_unicode = True,
                             autocommit = True)

    return result

def getManage():
    conn = getConnection()
    cur = conn.cursor()
    cur. callproc('personal2_select')
    if cur.rowcount:
        result = cur.fetchall()
    else:
        result = 0
    cur.close()
    conn.close()
    return result

def setManage(managedata):
    conn: getConnection()
    cur = conn.cursor()
    args =(managedata['name'],managedata['tell'],managedata['address'],managedata['sex'],managedata['birth'])
    cur.callproc('personal2_insert',args)
    result = cur.rowcount
    cur.close()
    conn.close()
    return json.dumps({'rows':result})

def putManage(managedata):
    conn = getConnection()
    cur = conn.cursor()
    args  = (managedata('id'), managedata('name'), managedata('tell'), managedata('address'), managedata('sex'),
             managedata('birth'))

    cur.callproc('personal2_update', args)
    cur.execute('SELECT @ personal2_update')
    result  =cur.fetchone()
    result = cur.rowcount
    cur.close()
    conn.close()
    return json.dumps({'rows':result})

def delManage(managedata):
    conn = getConnection()
    cur = conn.cursor()
    args = (managedata, 0)
    cur.callproc('personal2_delete', args)
    cur.execute('SELECT @ personal2_delete')
    result = cur.fetchone()
    result = cur.rowcount
    cur.close()
    conn.close()
    return json.dumps({'rows':result})