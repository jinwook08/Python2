from flask import Flask,request,render_template
from check import manage
from check.manage import getManage

app = Flask(__name__)


@app.route('/index')
def index():
    result = manage.getManage()
    return render_template('index.html', obj_list =result)

@app.route('/manageAct', methods= ['GET', 'POST', 'PUT', 'DELETE'])
def manageAct():
    if request.method == 'GET':
        return getManage()

    elif request.method == 'POST':
        name = request.form['name_set']
        tell = request.form['tell_set']
        address = request.form['address_set']
        sex = request.form['sex_set']
        birth = request.form['birth.set']
        managedata = {'name' : name, 'tell':tell, 'address':address, 'sex':sex, 'birht':birth}
        return manage.setManage(managedata)
    elif request.method == 'PUT':
        managedata = request.form['id']
        return manage.putManage(managedata)
    elif request.method == 'DELETE':
        managedata = request.form['id']
        return manage.delManage(managedata)


if __name__ == '__main__':
    app.run()
